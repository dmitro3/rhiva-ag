import { XiorInstance } from 'xior';
import { Cluster } from '../solana/type.js';
import { ApiClmmConfigInfo, ApiCpmmConfigInfo, ApiV3Token, FetchPoolParams, PoolsApiReturn, ApiV3PoolInfoItem, PoolKeys, FormatFarmInfoOut, FormatFarmKeyOut, AvailabilityCheckAPI3, ApiLaunchConfig } from './type.js';
import { API_URL_CONFIG } from './url.js';
import { PublicKey } from '@solana/web3.js';

declare function endlessRetry<T>(name: string, call: () => Promise<T>, interval?: number): Promise<T>;
interface ApiProps {
    cluster: Cluster;
    timeout: number;
    logRequests?: boolean;
    logCount?: number;
    urlConfigs?: API_URL_CONFIG;
}
declare class Api {
    cluster: Cluster;
    api: XiorInstance;
    logCount: number;
    urlConfigs: API_URL_CONFIG;
    constructor({ cluster, timeout, logRequests, logCount, urlConfigs }: ApiProps);
    getClmmConfigs(): Promise<ApiClmmConfigInfo[]>;
    getCpmmConfigs(): Promise<ApiCpmmConfigInfo[]>;
    getClmmPoolLines(poolId: string): Promise<{
        price: string;
        liquidity: string;
    }[]>;
    getBlockSlotCountForSecond(endpointUrl?: string): Promise<number>;
    getChainTimeOffset(): Promise<{
        offset: number;
    }>;
    getRpcs(): Promise<{
        rpcs: {
            batch: boolean;
            name: string;
            url: string;
            weight: number;
        }[];
        strategy: string;
    }>;
    getTokenList(): Promise<{
        mintList: ApiV3Token[];
        blacklist: string[];
        whiteList: string[];
    }>;
    getJupTokenList(): Promise<(ApiV3Token & {
        freeze_authority: string | null;
        mint_authority: string | null;
        permanent_delegate: string | null;
        minted_at: string;
    })[]>;
    getTokenInfo(mint: (string | PublicKey)[]): Promise<ApiV3Token[]>;
    getPoolList(props?: FetchPoolParams): Promise<PoolsApiReturn>;
    fetchPoolById(props: {
        ids: string;
    }): Promise<ApiV3PoolInfoItem[]>;
    fetchPoolKeysById(props: {
        idList: string[];
    }): Promise<PoolKeys[]>;
    fetchPoolByMints(props: {
        mint1: string | PublicKey;
        mint2?: string | PublicKey;
    } & Omit<FetchPoolParams, "pageSize">): Promise<PoolsApiReturn>;
    fetchFarmInfoById(props: {
        ids: string;
    }): Promise<FormatFarmInfoOut[]>;
    fetchFarmKeysById(props: {
        ids: string;
    }): Promise<FormatFarmKeyOut[]>;
    fetchAvailabilityStatus(): Promise<AvailabilityCheckAPI3>;
    fetchLaunchConfigs(): Promise<ApiLaunchConfig[]>;
}

export { Api, ApiProps, endlessRetry };
