import { EpochInfo } from '@solana/web3.js';
import BN__default from 'bn.js';
import { TransferFeeConfig } from '@solana/spl-token';
import { TransferFeeDataBaseType } from '../api/type.js';
import { G as GetTransferAmountFee } from '../type-37212561.js';
import '../api/api.js';
import 'xior';
import '../solana/type.js';
import '../api/url.js';
import '../amount-4d60f77d.js';
import 'decimal.js';
import './logger.js';
import '../module/currency.js';
import '../module/token.js';
import './pubKey.js';
import '../raydium/token/type.js';
import './owner.js';
import './txTool/lookupTable.js';
import './txTool/txType.js';

declare function getTransferAmountFee(amount: BN__default, feeConfig: TransferFeeConfig | undefined, epochInfo: EpochInfo, addFee: boolean): GetTransferAmountFee;
declare function getTransferAmountFeeV2(amount: BN__default, _feeConfig: TransferFeeDataBaseType | undefined, epochInfo: EpochInfo, addFee: boolean): GetTransferAmountFee;
declare function minExpirationTime(expirationTime1: number | undefined, expirationTime2: number | undefined): number | undefined;
declare function BNDivCeil(bn1: BN__default, bn2: BN__default): BN__default;
declare function ceilDivBN(amountA: BN__default, amountB: BN__default): BN__default;
declare function getTransferAmountFeeFromPre(amount: BN__default, feeConfig: TransferFeeConfig | undefined, slot: number): GetTransferAmountFee;
declare function getTransferAmountFeeFromPost(amount: BN__default, feeConfig: TransferFeeConfig | undefined, slot: number): GetTransferAmountFee;

export { BNDivCeil, ceilDivBN, getTransferAmountFee, getTransferAmountFeeFromPost, getTransferAmountFeeFromPre, getTransferAmountFeeV2, minExpirationTime };
