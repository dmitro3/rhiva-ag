import { PublicKey } from '@solana/web3.js';
import { n as ReplaceType } from '../type-37212561.js';
import 'bn.js';
import '@solana/spl-token';
import '../api/api.js';
import 'xior';
import '../solana/type.js';
import '../api/type.js';
import '../api/url.js';
import '../amount-4d60f77d.js';
import 'decimal.js';
import './logger.js';
import '../module/currency.js';
import '../module/token.js';
import './pubKey.js';
import '../raydium/token/type.js';
import './owner.js';
import './txTool/lookupTable.js';
import './txTool/txType.js';

declare function sleep(ms: number): Promise<void>;
declare function getTimestamp(): number;
declare function notInnerObject(v: unknown): v is Record<string, any>;
declare function jsonInfo2PoolKeys<T>(jsonInfo: T): ReplaceType<T, string, PublicKey>;

export { getTimestamp, jsonInfo2PoolKeys, notInnerObject, sleep };
