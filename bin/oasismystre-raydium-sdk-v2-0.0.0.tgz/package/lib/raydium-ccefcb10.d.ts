import { PublicKey, Commitment, Connection, Transaction, Signer, TransactionInstruction, Keypair, EpochInfo } from '@solana/web3.js';
import { Api } from './api/api.js';
import { ClmmKeys, ApiV3PoolInfoConcentratedItem, CpmmKeys, ApiV3PoolInfoStandardItemCpmm, JupTokenType, ApiV3Token, AvailabilityCheckAPI3, ApiV3TokenRes } from './api/type.js';
import { API_URL_CONFIG } from './api/url.js';
import { Owner } from './common/owner.js';
import { Cluster } from './solana/type.js';
import { f as TxBuilder, A as AddInstructionParam, e as MakeTxData, C as ComputeBudgetConfig, j as TxTipConfig, g as MakeTransaction, d as MakeMultiTxData, m as ReturnTypeFetchMultipleMintInfos, G as GetTransferAmountFee, L as LoadParams, S as SignAllTransactions } from './type-37212561.js';
import { i as BigNumberish } from './amount-4d60f77d.js';
import { Logger } from './common/logger.js';
import BN__default from 'bn.js';
import Decimal from 'decimal.js';
import { TxVersion } from './common/txTool/txType.js';
import { ClmmPositionLayout, PositionInfoLayout, LockClPositionLayoutV2, PoolInfoLayout } from './raydium/clmm/layout.js';
import { m as CreateConcentratedPool, O as OpenPositionFromBase, o as OpenPositionFromBaseExtInfo, p as OpenPositionFromLiquidity, q as OpenPositionFromLiquidityExtInfo, I as IncreasePositionFromLiquidity, M as ManipulateLiquidityExtInfo, n as IncreasePositionFromBase, D as DecreaseLiquidity, z as ClosePositionExtInfo, L as LockPosition, F as ClmmLockAddress, H as HarvestLockPosition, r as InitRewardParams, B as InitRewardExtInfo, s as InitRewardsParams, t as SetRewardParams, u as SetRewardsParams, v as CollectRewardParams, w as CollectRewardsParams, x as HarvestAllRewardsParams, E as ClmmParsedRpcData, d as ComputeClmmPoolInfo, l as ReturnTypeFetchMultiplePoolTickArrays } from './type-2e92a2f1.js';
import { CpmmParsedRpcData, CpmmComputeData, CreateCpmmPoolParam, CreateCpmmPoolAddress, AddCpmmLiquidityParams, WithdrawCpmmLiquidityParams, CpmmSwapParams, LockCpmmLpParams, CpmmLockExtInfo, HarvestLockCpmmLpParams, HarvestMultiLockCpmmLpParams, CreateCpmmPoolPermissionParam, CollectCreatorFees, CollectMultiCreatorFees, ComputePairAmountParams } from './raydium/cpmm/type.js';
import { Structure } from './marshmallow/index.js';
import { TokenInfo } from './raydium/token/type.js';
import { TokenAccount, TokenAccountRaw, GetOrCreateTokenAccountParams, HandleTokenAccountParams } from './raydium/account/types.js';

interface ModuleBaseProps {
    scope: Raydium;
    moduleName: string;
}
declare class ModuleBase {
    scope: Raydium;
    private disabled;
    protected logger: Logger;
    constructor({ scope, moduleName }: ModuleBaseProps);
    protected createTxBuilder(feePayer?: PublicKey): TxBuilder;
    logDebug(...args: (string | number | Record<string, any>)[]): void;
    logInfo(...args: (string | number | Record<string, any>)[]): void;
    logAndCreateError(...args: (string | number | Record<string, any>)[]): void;
    checkDisabled(): void;
}

interface TokenAccountDataProp {
    tokenAccounts?: TokenAccount[];
    tokenAccountRawInfos?: TokenAccountRaw[];
    notSubscribeAccountChange?: boolean;
}
declare class Account extends ModuleBase {
    private _tokenAccounts;
    private _tokenAccountRawInfos;
    private _accountChangeListenerId?;
    private _accountListener;
    private _clientOwnedToken;
    private _notSubscribeAccountChange;
    private _accountFetchTime;
    constructor(params: TokenAccountDataProp & ModuleBaseProps);
    get tokenAccounts(): TokenAccount[];
    get tokenAccountRawInfos(): TokenAccountRaw[];
    set notSubscribeAccountChange(subscribe: boolean);
    updateTokenAccount({ tokenAccounts, tokenAccountRawInfos }: TokenAccountDataProp): Account;
    addAccountChangeListener(cbk: (data: TokenAccountDataProp) => void): Account;
    removeAccountChangeListener(cbk: (data: TokenAccountDataProp) => void): Account;
    getAssociatedTokenAccount(mint: PublicKey, programId?: PublicKey): PublicKey;
    resetTokenAccounts(): void;
    fetchWalletTokenAccounts(config?: {
        forceUpdate?: boolean;
        commitment?: Commitment;
    }): Promise<{
        tokenAccounts: TokenAccount[];
        tokenAccountRawInfos: TokenAccountRaw[];
    }>;
    clearAccountChangeCkb(): void;
    getCreatedTokenAccount({ mint, programId, associatedOnly, }: {
        mint: PublicKey;
        programId?: PublicKey;
        associatedOnly?: boolean;
    }): Promise<PublicKey | undefined>;
    getOrCreateTokenAccount(params: GetOrCreateTokenAccountParams): Promise<{
        account?: PublicKey;
        instructionParams?: AddInstructionParam;
    }>;
    checkOrCreateAta({ mint, programId, autoUnwrapWSOLToSOL, }: {
        mint: PublicKey;
        programId?: PublicKey;
        autoUnwrapWSOLToSOL?: boolean;
    }): Promise<{
        pubKey: PublicKey;
        newInstructions: AddInstructionParam;
    }>;
    handleTokenAccount(params: HandleTokenAccountParams): Promise<AddInstructionParam & {
        tokenAccount: PublicKey;
    }>;
    processTokenAccount(props: {
        mint: PublicKey;
        programId?: PublicKey;
        amount?: BigNumberish;
        useSOLBalance?: boolean;
        handleTokenAccount?: boolean;
        feePayer?: PublicKey;
    }): Promise<Promise<AddInstructionParam & {
        tokenAccount?: PublicKey;
    }>>;
}

declare class Clmm extends ModuleBase {
    constructor(params: ModuleBaseProps);
    getClmmPoolKeys(poolId: string): Promise<ClmmKeys>;
    createPool<T extends TxVersion>(props: CreateConcentratedPool<T>): Promise<MakeTxData<T, {
        mockPoolInfo: ApiV3PoolInfoConcentratedItem;
        address: ClmmKeys;
    }>>;
    openPositionFromBase<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, ownerInfo, tickLower, tickUpper, base, baseAmount, otherAmountMax, nft2022, associatedOnly, checkCreateATAOwner, withMetadata, getEphemeralSigners, computeBudgetConfig, txTipConfig, txVersion, feePayer, }: OpenPositionFromBase<T>): Promise<MakeTxData<T, OpenPositionFromBaseExtInfo>>;
    openPositionFromLiquidity<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, ownerInfo, amountMaxA, amountMaxB, tickLower, tickUpper, liquidity, associatedOnly, checkCreateATAOwner, withMetadata, txVersion, computeBudgetConfig, txTipConfig, getEphemeralSigners, nft2022, feePayer, }: OpenPositionFromLiquidity<T>): Promise<MakeTxData<T, OpenPositionFromLiquidityExtInfo>>;
    increasePositionFromLiquidity<T extends TxVersion>(props: IncreasePositionFromLiquidity<T>): Promise<MakeTxData<T, ManipulateLiquidityExtInfo>>;
    increasePositionFromBase<T extends TxVersion>(props: IncreasePositionFromBase<T>): Promise<MakeTxData<T, ManipulateLiquidityExtInfo>>;
    decreaseLiquidity<T extends TxVersion>(props: DecreaseLiquidity<T>): Promise<MakeTxData<T, ManipulateLiquidityExtInfo & Partial<ClosePositionExtInfo>>>;
    lockPosition<T extends TxVersion>(props: LockPosition<T>): Promise<MakeTxData<ClmmLockAddress>>;
    harvestLockPosition<T extends TxVersion>(props: HarvestLockPosition<T>): Promise<MakeTxData<T>>;
    closePosition<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, ownerPosition, txVersion, computeBudgetConfig, txTipConfig, feePayer, }: {
        poolInfo: ApiV3PoolInfoConcentratedItem;
        poolKeys?: ClmmKeys;
        ownerPosition: ClmmPositionLayout;
        computeBudgetConfig?: ComputeBudgetConfig;
        txTipConfig?: TxTipConfig;
        txVersion: T;
        feePayer?: PublicKey;
    }): Promise<MakeTxData<T, ClosePositionExtInfo>>;
    initReward<T extends TxVersion>({ poolInfo, ownerInfo, rewardInfo, associatedOnly, checkCreateATAOwner, computeBudgetConfig, txVersion, feePayer, }: InitRewardParams<T>): Promise<MakeTxData<T, InitRewardExtInfo>>;
    initRewards<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, ownerInfo, rewardInfos, associatedOnly, checkCreateATAOwner, computeBudgetConfig, txTipConfig, txVersion, feePayer, }: InitRewardsParams<T>): Promise<MakeTxData<T, {
        address: Record<string, PublicKey>;
    }>>;
    setReward<T extends TxVersion>({ poolInfo, ownerInfo, rewardInfo, associatedOnly, checkCreateATAOwner, computeBudgetConfig, txTipConfig, txVersion, feePayer, }: SetRewardParams<T>): Promise<MakeTxData<T, {
        address: Record<string, PublicKey>;
    }>>;
    setRewards<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, ownerInfo, rewardInfos, associatedOnly, checkCreateATAOwner, computeBudgetConfig, txTipConfig, txVersion, feePayer, }: SetRewardsParams<T>): Promise<MakeTxData<T, {
        address: Record<string, PublicKey>;
    }>>;
    collectReward<T extends TxVersion>({ poolInfo, ownerInfo, rewardMint, associatedOnly, checkCreateATAOwner, computeBudgetConfig, txTipConfig, txVersion, feePayer, }: CollectRewardParams<T>): Promise<MakeTxData<{
        address: Record<string, PublicKey>;
    }>>;
    collectRewards({ poolInfo, ownerInfo, rewardMints, associatedOnly, checkCreateATAOwner, computeBudgetConfig, txTipConfig, feePayer, }: CollectRewardsParams): Promise<MakeTransaction>;
    swap<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, inputMint, amountIn, amountOutMin, priceLimit, observationId, ownerInfo, remainingAccounts, associatedOnly, checkCreateATAOwner, txVersion, computeBudgetConfig, txTipConfig, feePayer, }: {
        poolInfo: ApiV3PoolInfoConcentratedItem;
        poolKeys?: ClmmKeys;
        inputMint: string | PublicKey;
        amountIn: BN__default;
        amountOutMin: BN__default;
        priceLimit?: Decimal;
        observationId: PublicKey;
        ownerInfo: {
            useSOLBalance?: boolean;
            feePayer?: PublicKey;
        };
        remainingAccounts: PublicKey[];
        associatedOnly?: boolean;
        checkCreateATAOwner?: boolean;
        txVersion?: T;
        computeBudgetConfig?: ComputeBudgetConfig;
        txTipConfig?: TxTipConfig;
        feePayer?: PublicKey;
    }): Promise<MakeTxData<T>>;
    swapBaseOut<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, outputMint, amountOut, amountInMax, priceLimit, observationId, ownerInfo, remainingAccounts, associatedOnly, checkCreateATAOwner, txVersion, computeBudgetConfig, txTipConfig, feePayer, }: {
        poolInfo: ApiV3PoolInfoConcentratedItem;
        poolKeys?: ClmmKeys;
        outputMint: string | PublicKey;
        amountOut: BN__default;
        amountInMax: BN__default;
        priceLimit?: Decimal;
        observationId: PublicKey;
        ownerInfo: {
            useSOLBalance?: boolean;
            feePayer?: PublicKey;
        };
        remainingAccounts: PublicKey[];
        associatedOnly?: boolean;
        checkCreateATAOwner?: boolean;
        txVersion?: T;
        computeBudgetConfig?: ComputeBudgetConfig;
        txTipConfig?: TxTipConfig;
        feePayer?: PublicKey;
    }): Promise<MakeTxData<T>>;
    harvestAllRewards<T extends TxVersion = TxVersion.LEGACY>({ allPoolInfo, allPositions, lockInfo, ownerInfo, associatedOnly, checkCreateATAOwner, programId, txVersion, computeBudgetConfig, feePayer, lockProgram, lockAuth, clmmProgram, }: HarvestAllRewardsParams<T>): Promise<MakeMultiTxData<T>>;
    getWhiteListMint({ programId }: {
        programId: PublicKey;
    }): Promise<PublicKey[]>;
    getOwnerPositionInfo({ programId, }: {
        programId?: string | PublicKey;
    }): Promise<ReturnType<typeof PositionInfoLayout.decode>[]>;
    getOwnerLockedPositionInfo({ programId, }: {
        programId?: string | PublicKey;
    }): Promise<{
        position: ReturnType<typeof PositionInfoLayout.decode>;
        lockInfo: ReturnType<typeof LockClPositionLayoutV2.decode>;
    }[]>;
    getRpcClmmPoolInfo({ poolId }: {
        poolId: string | PublicKey;
    }): Promise<ClmmParsedRpcData>;
    getRpcClmmPoolInfos({ poolIds, config, }: {
        poolIds: (string | PublicKey)[];
        config?: {
            batchRequest?: boolean;
            chunkCount?: number;
        };
    }): Promise<{
        [poolId: string]: ClmmParsedRpcData;
    }>;
    getComputeClmmPoolInfos({ clmmPoolsRpcInfo, mintInfos, }: {
        clmmPoolsRpcInfo: Record<string, ReturnType<typeof PoolInfoLayout.decode> & {
            currentPrice: number;
            programId: PublicKey;
        }>;
        mintInfos: ReturnTypeFetchMultipleMintInfos;
    }): Promise<{
        computeClmmPoolInfo: Record<string, ComputeClmmPoolInfo>;
        computePoolTickData: ReturnTypeFetchMultiplePoolTickArrays;
    }>;
    getPoolInfoFromRpc(poolId: string): Promise<{
        poolInfo: ApiV3PoolInfoConcentratedItem;
        poolKeys: ClmmKeys;
        computePoolInfo: ComputeClmmPoolInfo;
        tickData: ReturnTypeFetchMultiplePoolTickArrays;
    }>;
}

declare class CpmmModule extends ModuleBase {
    constructor(params: ModuleBaseProps);
    load(): Promise<void>;
    getCpmmPoolKeys(poolId: string): Promise<CpmmKeys>;
    getRpcPoolInfo(poolId: string, fetchConfigInfo?: boolean): Promise<CpmmParsedRpcData>;
    getRpcPoolInfos(poolIds: string[], fetchConfigInfo?: boolean): Promise<{
        [poolId: string]: CpmmParsedRpcData;
    }>;
    toComputePoolInfos({ pools, mintInfos, }: {
        pools: Record<string, CpmmParsedRpcData>;
        mintInfos: ReturnTypeFetchMultipleMintInfos;
    }): Record<string, CpmmComputeData>;
    getPoolInfoFromRpc(poolId: string): Promise<{
        poolInfo: ApiV3PoolInfoStandardItemCpmm;
        poolKeys: CpmmKeys;
        rpcData: CpmmParsedRpcData;
    }>;
    createPool<T extends TxVersion>({ poolId, programId, poolFeeAccount, startTime, ownerInfo, associatedOnly, checkCreateATAOwner, txVersion, feeConfig, computeBudgetConfig, txTipConfig, feePayer, ...params }: CreateCpmmPoolParam<T>): Promise<MakeTxData<T, {
        address: CreateCpmmPoolAddress;
    }>>;
    addLiquidity<T extends TxVersion>(params: AddCpmmLiquidityParams<T>): Promise<MakeTxData<T>>;
    withdrawLiquidity<T extends TxVersion>(params: WithdrawCpmmLiquidityParams<T>): Promise<MakeTxData<T>>;
    swap<T extends TxVersion>(params: CpmmSwapParams<T>): Promise<MakeTxData<T>>;
    lockLp<T extends TxVersion>(params: LockCpmmLpParams<T>): Promise<MakeTxData<CpmmLockExtInfo>>;
    harvestLockLp<T extends TxVersion>(params: HarvestLockCpmmLpParams<T>): Promise<MakeTxData>;
    harvestMultiLockLp<T extends TxVersion>(params: HarvestMultiLockCpmmLpParams<T>): Promise<MakeMultiTxData<T>>;
    createPoolWithPermission<T extends TxVersion>({ poolId, programId, poolFeeAccount, startTime, ownerInfo, associatedOnly, checkCreateATAOwner, txVersion, feeConfig, computeBudgetConfig, txTipConfig, feePayer, feeOn, ...params }: CreateCpmmPoolPermissionParam<T>): Promise<MakeTxData<T, {
        address: CreateCpmmPoolAddress;
    }>>;
    collectCreatorFees<T extends TxVersion>({ poolInfo, poolKeys: propPoolKeys, programId, txVersion, computeBudgetConfig, txTipConfig, feePayer, }: CollectCreatorFees<T>): Promise<MakeTxData<T>>;
    collectMultiCreatorFees<T extends TxVersion>({ poolInfoList, programId, txVersion, computeBudgetConfig, feePayer, }: CollectMultiCreatorFees<T>): Promise<MakeMultiTxData<T>>;
    computeSwapAmount({ pool, amountIn, outputMint, slippage, swapBaseIn, }: {
        pool: CpmmComputeData;
        amountIn: BN__default;
        outputMint: string | PublicKey;
        slippage: number;
        swapBaseIn?: boolean;
    }): {
        allTrade: boolean;
        amountIn: BN__default;
        amountOut: BN__default;
        minAmountOut: BN__default;
        fee: BN__default;
        executionPrice: Decimal;
        priceImpact: any;
    };
    computePairAmount({ poolInfo, baseReserve, quoteReserve, amount, slippage, epochInfo, baseIn, }: ComputePairAmountParams): {
        inputAmountFee: GetTransferAmountFee;
        anotherAmount: GetTransferAmountFee;
        maxAnotherAmount: GetTransferAmountFee;
        minAnotherAmount: GetTransferAmountFee;
        liquidity: BN__default;
    };
}

interface SHOW_INFO {
    programId: PublicKey;
    poolId: PublicKey;
    ammId: PublicKey;
    ownerAccountId: PublicKey;
    snapshotLpAmount: BN__default;
    openTime: number;
    endTime: number;
    project: typeof Utils1216.VERSION_PROJECT[number];
    canClaim: boolean;
    canClaimErrorType: canClaimErrorType;
    tokenInfo: {
        mintAddress: PublicKey;
        mintVault: PublicKey;
        mintDecimals: number;
        perLpLoss: BN__default;
        debtAmount: BN__default;
    }[];
}
type canClaimErrorType = "outOfOperationalTime" | "alreadyClaimIt" | undefined;
declare class Utils1216 extends ModuleBase {
    static CLAIMED_NUM: number;
    static POOL_LAYOUT: Structure<number | PublicKey | Buffer | BN__default | BN__default[] | {
        mintDecimals: number;
        mintAddress: PublicKey;
        mintVault: PublicKey;
        perLpLoss: BN__default;
        totalClaimedAmount: BN__default;
    }[], "", {
        status: number;
        bump: number;
        openTime: BN__default;
        endTime: BN__default;
        padding: BN__default[];
        ammId: PublicKey;
        tokenInfo: {
            mintDecimals: number;
            mintAddress: PublicKey;
            mintVault: PublicKey;
            perLpLoss: BN__default;
            totalClaimedAmount: BN__default;
        }[];
    }>;
    static OWNER_LAYOUT: Structure<number | PublicKey | Buffer | BN__default | BN__default[] | {
        mintAddress: PublicKey;
        debtAmount: BN__default;
        claimedAmount: BN__default;
    }[], "", {
        owner: PublicKey;
        poolId: PublicKey;
        bump: number;
        padding: BN__default[];
        version: number;
        lpAmount: BN__default;
        tokenInfo: {
            mintAddress: PublicKey;
            debtAmount: BN__default;
            claimedAmount: BN__default;
        }[];
    }>;
    static DEFAULT_POOL_ID: PublicKey[];
    static SEED_CONFIG: {
        pool: {
            id: Buffer;
        };
        owner: {
            id: Buffer;
        };
    };
    static VERSION_PROJECT: readonly [undefined, "Francium", "Tulip", "Larix"];
    static getPdaPoolId(programId: PublicKey, ammId: PublicKey): {
        publicKey: PublicKey;
        nonce: number;
    };
    static getPdaOwnerId(programId: PublicKey, poolId: PublicKey, owner: PublicKey, version: number): {
        publicKey: PublicKey;
        nonce: number;
    };
    static getAllInfo({ connection, programId, poolIds, wallet, chainTime, }: {
        connection: Connection;
        programId: PublicKey;
        poolIds: PublicKey[];
        wallet: PublicKey;
        chainTime: number;
    }): Promise<SHOW_INFO[]>;
    makeClaimTransaction({ poolInfo, ownerInfo, feePayer, }: {
        connection: Connection;
        poolInfo: SHOW_INFO;
        ownerInfo: {
            wallet?: PublicKey;
            associatedOnly: boolean;
        };
        feePayer?: PublicKey;
    }): Promise<{
        transaction: Transaction;
        signer: Signer[];
    }[]>;
    makeClaimAllTransaction({ poolInfos, ownerInfo, feePayer, }: {
        poolInfos: SHOW_INFO[];
        ownerInfo: {
            wallet?: PublicKey;
            associatedOnly: boolean;
        };
        feePayer?: PublicKey;
    }): Promise<{
        transaction: Transaction;
        signer: Signer[];
    }[]>;
    static makeClaimInstruction({ programId, poolInfo, ownerInfo, }: {
        programId: PublicKey;
        poolInfo: SHOW_INFO;
        ownerInfo: {
            wallet: PublicKey;
            ownerPda: PublicKey;
            claimAddress: PublicKey[];
        };
    }): TransactionInstruction;
}

declare class TokenModule extends ModuleBase {
    private _tokenList;
    private _tokenMap;
    private _blackTokenMap;
    private _mintGroup;
    private _whiteMap;
    private _extraTokenList;
    constructor(params: ModuleBaseProps);
    load(params?: LoadParams & {
        type?: JupTokenType;
    }): Promise<void>;
    get tokenList(): TokenInfo[];
    get tokenMap(): Map<string, TokenInfo>;
    get blackTokenMap(): Set<string>;
    get mintGroup(): {
        official: Set<string>;
        jup: Set<string>;
    };
    get whiteListMap(): Set<string>;
    /** === util functions === */
    getTokenInfo(mint: string | PublicKey): Promise<ApiV3Token>;
}

interface RaydiumLoadParams extends TokenAccountDataProp, Omit<RaydiumApiBatchRequestParams, "api"> {
    connection: Connection;
    cluster?: Cluster;
    owner?: PublicKey | Keypair;
    apiRequestInterval?: number;
    apiRequestTimeout?: number;
    apiCacheTime?: number;
    signAllTransactions?: SignAllTransactions;
    urlConfigs?: API_URL_CONFIG;
    logRequests?: boolean;
    logCount?: number;
    jupTokenType?: JupTokenType;
    disableFeatureCheck?: boolean;
    disableLoadToken?: boolean;
    blockhashCommitment?: Commitment;
    loopMultiTxStatus?: boolean;
}
interface RaydiumApiBatchRequestParams {
    api: Api;
    defaultChainTimeOffset?: number;
    defaultChainTime?: number;
}
type RaydiumConstructorParams = Required<RaydiumLoadParams> & RaydiumApiBatchRequestParams;
interface DataBase<T> {
    fetched: number;
    data: T;
    extInfo?: Record<string, any>;
}
interface ApiData {
    tokens?: DataBase<ApiV3Token[]>;
    tokenList?: DataBase<ApiV3TokenRes>;
    jupTokenList?: DataBase<ApiV3Token[]>;
}
declare class Raydium {
    cluster: Cluster;
    account: Account;
    clmm: Clmm;
    cpmm: CpmmModule;
    utils1216: Utils1216;
    token: TokenModule;
    rawBalances: Map<string, string>;
    apiData: ApiData;
    availability: Partial<AvailabilityCheckAPI3>;
    blockhashCommitment: Commitment;
    loopMultiTxStatus?: boolean;
    private _connection;
    private _owner;
    api: Api;
    private _apiCacheTime;
    private _signAllTransactions?;
    private _chainTime?;
    private _epochInfo?;
    constructor(config: RaydiumConstructorParams);
    static load(config: RaydiumLoadParams): Promise<Raydium>;
    get owner(): Owner | undefined;
    get ownerPubKey(): PublicKey;
    setOwner(owner?: PublicKey | Keypair): Raydium;
    get connection(): Connection;
    setConnection(connection: Connection): Raydium;
    get signAllTransactions(): SignAllTransactions | undefined;
    setSignAllTransactions(signAllTransactions?: SignAllTransactions): Raydium;
    checkOwner(): void;
    private isCacheInvalidate;
    fetchChainTime(): Promise<void>;
    fetchV3TokenList(forceUpdate?: boolean): Promise<ApiV3TokenRes>;
    fetchJupTokenList(forceUpdate?: boolean): Promise<ApiV3Token[]>;
    get chainTimeData(): {
        offset: number;
        chainTime: number;
    } | undefined;
    chainTimeOffset(): Promise<number>;
    currentBlockChainTime(): Promise<number>;
    fetchEpochInfo(): Promise<EpochInfo>;
    fetchAvailabilityStatus(skipCheck?: boolean): Promise<Partial<AvailabilityCheckAPI3>>;
}

export { Account as A, Clmm as C, ModuleBase as M, RaydiumLoadParams as R, SHOW_INFO as S, TokenAccountDataProp as T, Utils1216 as U, RaydiumApiBatchRequestParams as a, RaydiumConstructorParams as b, Raydium as c, canClaimErrorType as d, ModuleBaseProps as e, CpmmModule as f, TokenModule as g };
