import { PublicKey, Connection } from '@solana/web3.js';
import BN__default from 'bn.js';
import { Q as TickArray, P as Tick } from '../../../type-2e92a2f1.js';
import { TickArrayBitmapExtensionLayout } from '../layout.js';
import 'decimal.js';
import '../../../api/type.js';
import '../../../common/txTool/txType.js';
import '../../../amount-4d60f77d.js';
import '../../../common/logger.js';
import '../../../module/currency.js';
import '../../../module/token.js';
import '../../../common/pubKey.js';
import '../../token/type.js';
import '../../../type-37212561.js';
import '@solana/spl-token';
import '../../../api/api.js';
import 'xior';
import '../../../solana/type.js';
import '../../../api/url.js';
import '../../../common/owner.js';
import '../../../common/txTool/lookupTable.js';
import '../../../marshmallow/index.js';
import '../../../marshmallow/buffer-layout.js';

declare const FETCH_TICKARRAY_COUNT = 15;
declare type PoolVars = {
    key: PublicKey;
    tokenA: PublicKey;
    tokenB: PublicKey;
    fee: number;
};
declare class TickQuery {
    static getTickArrays(connection: Connection, programId: PublicKey, poolId: PublicKey, tickCurrent: number, tickSpacing: number, tickArrayBitmapArray: BN__default[], exTickArrayBitmap: ReturnType<typeof TickArrayBitmapExtensionLayout.decode>): Promise<{
        [key: string]: TickArray;
    }>;
    static nextInitializedTick(programId: PublicKey, poolId: PublicKey, tickArrayCache: {
        [key: string]: TickArray;
    }, tickIndex: number, tickSpacing: number, zeroForOne: boolean): {
        nextTick: Tick;
        tickArrayAddress: PublicKey | undefined;
        tickArrayStartTickIndex: number;
    };
    static nextInitializedTickArray(tickIndex: number, tickSpacing: number, zeroForOne: boolean, tickArrayBitmap: BN__default[], exBitmapInfo: ReturnType<typeof TickArrayBitmapExtensionLayout.decode>): {
        isExist: boolean;
        nextStartIndex: number;
    };
    static firstInitializedTickInOneArray(programId: PublicKey, poolId: PublicKey, tickArray: TickArray, zeroForOne: boolean): {
        nextTick: Tick | undefined;
        tickArrayAddress: PublicKey;
        tickArrayStartTickIndex: number;
    };
    static nextInitializedTickInOneArray(programId: PublicKey, poolId: PublicKey, tickArrayCache: {
        [key: string]: TickArray;
    }, tickIndex: number, tickSpacing: number, zeroForOne: boolean): {
        initializedTick: Tick | undefined;
        tickArrayAddress: PublicKey | undefined;
        tickArrayStartTickIndex: number;
    };
    static getArrayStartIndex(tickIndex: number, tickSpacing: number): number;
    static checkIsValidStartIndex(tickIndex: number, tickSpacing: number): boolean;
    static tickCount(tickSpacing: number): number;
}

export { FETCH_TICKARRAY_COUNT, PoolVars, TickQuery };
