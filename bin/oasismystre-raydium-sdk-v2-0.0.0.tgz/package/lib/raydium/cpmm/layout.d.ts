import { Structure } from '../../marshmallow/index.js';
import * as BN from 'bn.js';
import * as _solana_web3_js from '@solana/web3.js';
import '../../marshmallow/buffer-layout.js';

declare const CpmmConfigInfoLayout: Structure<number | boolean | _solana_web3_js.PublicKey | Buffer | BN | BN[], "", {
    bump: number;
    index: number;
    protocolFeeRate: BN;
    tradeFeeRate: BN;
    disableCreatePool: boolean;
    fundFeeRate: BN;
    createPoolFee: BN;
    protocolOwner: _solana_web3_js.PublicKey;
    fundOwner: _solana_web3_js.PublicKey;
    creatorFeeRate: BN;
}>;
declare const CpmmPoolInfoLayout: Structure<number | boolean | _solana_web3_js.PublicKey | number[] | Buffer | BN | BN[], "", {
    status: number;
    bump: number;
    mintA: _solana_web3_js.PublicKey;
    mintB: _solana_web3_js.PublicKey;
    vaultA: _solana_web3_js.PublicKey;
    vaultB: _solana_web3_js.PublicKey;
    observationId: _solana_web3_js.PublicKey;
    openTime: BN;
    configId: _solana_web3_js.PublicKey;
    poolCreator: _solana_web3_js.PublicKey;
    mintLp: _solana_web3_js.PublicKey;
    mintProgramA: _solana_web3_js.PublicKey;
    mintProgramB: _solana_web3_js.PublicKey;
    lpDecimals: number;
    mintDecimalA: number;
    mintDecimalB: number;
    lpAmount: BN;
    protocolFeesMintA: BN;
    protocolFeesMintB: BN;
    fundFeesMintA: BN;
    fundFeesMintB: BN;
    epoch: BN;
    feeOn: number;
    enableCreatorFee: boolean;
    creatorFeesMintA: BN;
    creatorFeesMintB: BN;
}>;
declare const CpmmPermission: Structure<_solana_web3_js.PublicKey | Buffer | BN[], "", {
    configId: _solana_web3_js.PublicKey;
}>;

export { CpmmConfigInfoLayout, CpmmPermission, CpmmPoolInfoLayout };
