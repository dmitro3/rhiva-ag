import { PublicKey, EpochInfo } from '@solana/web3.js';
import BN__default from 'bn.js';
import Decimal from 'decimal.js';
import { ApiV3Token, ApiCpmmConfigInfo, ApiV3PoolInfoStandardItemCpmm, CpmmKeys } from '../../api/type.js';
import { TxVersion } from '../../common/txTool/txType.js';
import { P as Percent } from '../../amount-4d60f77d.js';
import { C as ComputeBudgetConfig, j as TxTipConfig, G as GetTransferAmountFee } from '../../type-37212561.js';
import { SwapResult } from './curve/calculator.js';
import { CpmmPoolInfoLayout, CpmmConfigInfoLayout } from './layout.js';
import '../../common/logger.js';
import '../../module/currency.js';
import '../../module/token.js';
import '../../common/pubKey.js';
import '../token/type.js';
import '@solana/spl-token';
import '../../api/api.js';
import 'xior';
import '../../solana/type.js';
import '../../api/url.js';
import '../../common/owner.js';
import '../../common/txTool/lookupTable.js';
import '../../marshmallow/index.js';
import '../../marshmallow/buffer-layout.js';

interface CreateCpmmPoolParam<T> {
    poolId?: PublicKey;
    programId: PublicKey;
    poolFeeAccount: PublicKey;
    mintA: Pick<ApiV3Token, "address" | "decimals" | "programId">;
    mintB: Pick<ApiV3Token, "address" | "decimals" | "programId">;
    mintAAmount: BN__default;
    mintBAmount: BN__default;
    startTime: BN__default;
    feeConfig: ApiCpmmConfigInfo;
    associatedOnly: boolean;
    checkCreateATAOwner?: boolean;
    ownerInfo: {
        feePayer?: PublicKey;
        useSOLBalance?: boolean;
    };
    computeBudgetConfig?: ComputeBudgetConfig;
    txVersion?: T;
    txTipConfig?: TxTipConfig;
    feePayer?: PublicKey;
}
interface CreateCpmmPoolPermissionParam<T> {
    poolId?: PublicKey;
    programId: PublicKey;
    poolFeeAccount: PublicKey;
    mintA: Pick<ApiV3Token, "address" | "decimals" | "programId">;
    mintB: Pick<ApiV3Token, "address" | "decimals" | "programId">;
    mintAAmount: BN__default;
    mintBAmount: BN__default;
    startTime: BN__default;
    feeConfig: ApiCpmmConfigInfo;
    associatedOnly: boolean;
    checkCreateATAOwner?: boolean;
    ownerInfo: {
        feePayer?: PublicKey;
        useSOLBalance?: boolean;
    };
    computeBudgetConfig?: ComputeBudgetConfig;
    txVersion?: T;
    txTipConfig?: TxTipConfig;
    feePayer?: PublicKey;
    feeOn: FeeOn;
}
interface CreateCpmmPoolAddress {
    poolId: PublicKey;
    configId: PublicKey;
    authority: PublicKey;
    lpMint: PublicKey;
    vaultA: PublicKey;
    vaultB: PublicKey;
    observationId: PublicKey;
    mintA: ApiV3Token;
    mintB: ApiV3Token;
    programId: PublicKey;
    poolFeeAccount: PublicKey;
    feeConfig: ApiCpmmConfigInfo;
}
interface AddCpmmLiquidityParams<T = TxVersion.LEGACY> {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    poolKeys?: CpmmKeys;
    payer?: PublicKey;
    inputAmount: BN__default;
    baseIn: boolean;
    slippage: Percent;
    config?: {
        bypassAssociatedCheck?: boolean;
        checkCreateATAOwner?: boolean;
    };
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
    computeResult?: {
        inputAmountFee: GetTransferAmountFee;
        anotherAmount: GetTransferAmountFee;
        maxAnotherAmount: GetTransferAmountFee;
        liquidity: BN__default;
    };
    feePayer?: PublicKey;
}
interface WithdrawCpmmLiquidityParams<T = TxVersion.LEGACY> {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    poolKeys?: CpmmKeys;
    payer?: PublicKey;
    lpAmount: BN__default;
    slippage: Percent;
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
    feePayer?: PublicKey;
    closeWsol?: boolean;
}
interface CpmmSwapParams<T = TxVersion.LEGACY> {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    poolKeys?: CpmmKeys;
    payer?: PublicKey;
    baseIn: boolean;
    fixedOut?: boolean;
    slippage?: number;
    swapResult: Pick<SwapResult, "inputAmount" | "outputAmount">;
    inputAmount: BN__default;
    config?: {
        bypassAssociatedCheck?: boolean;
        checkCreateATAOwner?: boolean;
        associatedOnly?: boolean;
    };
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
    feePayer?: PublicKey;
}
interface ComputePairAmountParams {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    baseReserve: BN__default;
    quoteReserve: BN__default;
    amount: string | Decimal;
    slippage: Percent;
    epochInfo: EpochInfo;
    baseIn?: boolean;
}
type CpmmParsedRpcData = ReturnType<typeof CpmmPoolInfoLayout.decode> & {
    baseReserve: BN__default;
    quoteReserve: BN__default;
    vaultAAmount: BN__default;
    vaultBAmount: BN__default;
    configInfo?: ReturnType<typeof CpmmConfigInfoLayout.decode>;
    poolPrice: Decimal;
    programId: PublicKey;
};
type CpmmComputeData = {
    id: PublicKey;
    version: 7;
    configInfo: ReturnType<typeof CpmmConfigInfoLayout.decode>;
    mintA: ApiV3Token;
    mintB: ApiV3Token;
    authority: PublicKey;
} & Omit<CpmmParsedRpcData, "configInfo" | "mintA" | "mintB">;
type CpmmLockExtInfo = {
    nftMint: PublicKey;
    nftAccount: PublicKey;
    metadataAccount: PublicKey;
    lockPda: PublicKey;
    userLpVault: PublicKey;
    lockLpVault: PublicKey;
};
interface LockCpmmLpParams<T = TxVersion.LEGACY> {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    poolKeys?: CpmmKeys;
    lpAmount: BN__default;
    programId?: PublicKey;
    authProgram?: PublicKey;
    feePayer?: PublicKey;
    feeNftOwner?: PublicKey;
    withMetadata?: boolean;
    getEphemeralSigners?: (k: number) => any;
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
}
interface HarvestLockCpmmLpParams<T = TxVersion.LEGACY> {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    poolKeys?: CpmmKeys;
    nftMint: PublicKey;
    lpFeeAmount: BN__default;
    programId?: PublicKey;
    authProgram?: PublicKey;
    clmmProgram?: PublicKey;
    cpmmProgram?: {
        programId?: PublicKey;
        authProgram?: PublicKey;
    };
    feePayer?: PublicKey;
    withMetadata?: boolean;
    getEphemeralSigners?: (k: number) => any;
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
    closeWsol?: boolean;
}
interface HarvestMultiLockCpmmLpParams<T = TxVersion.LEGACY> {
    lockInfo: {
        poolInfo: ApiV3PoolInfoStandardItemCpmm;
        poolKeys?: CpmmKeys;
        nftMint: PublicKey;
        lpFeeAmount: BN__default;
    }[];
    programId?: PublicKey;
    authProgram?: PublicKey;
    clmmProgram?: PublicKey;
    cpmmProgram?: {
        programId?: PublicKey;
        authProgram?: PublicKey;
    };
    feePayer?: PublicKey;
    withMetadata?: boolean;
    getEphemeralSigners?: (k: number) => any;
    computeBudgetConfig?: ComputeBudgetConfig;
    txVersion?: T;
    closeWsol?: boolean;
}
interface CpmmLockNftBasicInfo {
    name: string;
    symbol: string;
    description: string;
    external_url: string;
    collection: {
        name: string;
        family: string;
    };
    image: string;
}
interface CpmmLockNftInfo extends CpmmLockNftBasicInfo {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    positionInfo: {
        percentage: number;
        usdValue: number;
        unclaimedFee: {
            lp: number;
            amountA: number;
            amountB: number;
            useValue: number;
        };
    };
}
interface CollectCreatorFees<T = TxVersion.LEGACY> {
    poolInfo: ApiV3PoolInfoStandardItemCpmm;
    poolKeys?: CpmmKeys;
    programId?: PublicKey;
    feePayer?: PublicKey;
    associatedOnly?: boolean;
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
}
interface CollectMultiCreatorFees<T = TxVersion.LEGACY> {
    poolInfoList: ApiV3PoolInfoStandardItemCpmm[];
    programId?: PublicKey;
    feePayer?: PublicKey;
    associatedOnly?: boolean;
    computeBudgetConfig?: ComputeBudgetConfig;
    txTipConfig?: TxTipConfig;
    txVersion?: T;
}
declare enum FeeOn {
    BothToken = 0,
    OnlyTokenA = 1,
    OnlyTokenB = 2
}

export { AddCpmmLiquidityParams, CollectCreatorFees, CollectMultiCreatorFees, ComputePairAmountParams, CpmmComputeData, CpmmLockExtInfo, CpmmLockNftBasicInfo, CpmmLockNftInfo, CpmmParsedRpcData, CpmmSwapParams, CreateCpmmPoolAddress, CreateCpmmPoolParam, CreateCpmmPoolPermissionParam, FeeOn, HarvestLockCpmmLpParams, HarvestMultiLockCpmmLpParams, LockCpmmLpParams, WithdrawCpmmLiquidityParams };
