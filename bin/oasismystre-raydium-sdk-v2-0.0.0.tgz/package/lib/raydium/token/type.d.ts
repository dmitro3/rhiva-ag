import { ApiV3Token } from '../../api/type.js';
import { TokenProps, Token } from '../../module/token.js';
import '@solana/web3.js';
import '../../common/pubKey.js';

type TokenInfo = ApiV3Token & {
    priority: number;
    userAdded?: boolean;
    type?: string;
};
interface TokenJson {
    symbol: string;
    name: string;
    mint: string;
    decimals: number;
    extensions: {
        coingeckoId?: string;
    };
    icon: string;
    hasFreeze?: boolean;
}
type SplToken = TokenProps & {
    icon: string;
    id: string;
    extensions: {
        [key in "coingeckoId" | "website" | "whitepaper"]?: string;
    };
    userAdded?: boolean;
};
type LpToken = Token & {
    isLp: true;
    base: SplToken;
    quote: SplToken;
    icon: string;
    /** mint. for `<TokenSelector>`*/
    id: string;
    extensions: {
        [key in "coingeckoId" | "website" | "whitepaper"]?: string;
    };
};

export { LpToken, SplToken, TokenInfo, TokenJson };
